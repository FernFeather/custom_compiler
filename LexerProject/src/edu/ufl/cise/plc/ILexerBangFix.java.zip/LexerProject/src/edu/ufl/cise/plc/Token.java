package edu.ufl.cise.plc;

public class Token implements IToken {
    final Kind kind;
    final SourceLocation srcLocation;
    final String input;
    final int length;

    Token(Kind kind, String input, SourceLocation srcLocation, int length) {
        this.kind = kind;
        this.input = input;
        this.srcLocation = srcLocation;
        this.length = length;
    }

    @Override
    public Kind getKind() {
        return this.kind;
    }

    @Override
    public String getText() {
        return input;
    }

    @Override
    public SourceLocation getSourceLocation() {
        return srcLocation;
    }

    @Override
    public int getIntValue() {

        return Integer.parseInt(input);
    }

    @Override
    public float getFloatValue() {
        return Float.parseFloat(input);
    }

    @Override
    public boolean getBooleanValue() {
        return Boolean.parseBoolean(input);
    }

    @Override
    public String getStringValue() {

        return input.substring(1, input.length());
    }
}