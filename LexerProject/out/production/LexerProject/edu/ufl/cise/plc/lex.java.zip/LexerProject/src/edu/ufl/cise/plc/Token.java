package edu.ufl.cise.plc;

public class Token implements IToken {
    final Kind kind;
    final String lexeme;
    final Object literal;
    final int line;

    Token(Kind kind, String lexeme, Object literal, int line) {
        this.kind = kind;
        this.lexeme = lexeme;
        this.literal = literal;
        this.line = line;
    }

    public String toString() {
        return kind + " " + lexeme + " " + literal;
    }

    @Override
    public Kind getKind() {
        return this.kind;
    }

    @Override
    public String getText() {
        return lexeme; //check this
    }

    @Override
    public SourceLocation getSourceLocation() {
        return null;
    }

    @Override
    public int getIntValue() {
        return 0;
    }

    @Override
    public float getFloatValue() {
        return 0;
    }

    @Override
    public boolean getBooleanValue() {
        return false;
    }

    @Override
    public String getStringValue() {
        return null;
    }
}