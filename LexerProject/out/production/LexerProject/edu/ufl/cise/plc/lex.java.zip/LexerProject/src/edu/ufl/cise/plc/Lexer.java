package edu.ufl.cise.plc;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Lexer implements ILexer {

    private String chars;
    private List<Token> tokens = new ArrayList<>();

    private int start = 0;
    private int pos = 0;
    private int line = 1;

    /* Implements DFA Pass in String containing source to tokenize in constructor */
    public Lexer(String input) {
        String chars = input;
    }

    @Override
    public IToken next() throws LexicalException {
        return null;
    }

    @Override
    public IToken peek() throws LexicalException {
    }

    // 1. Define an enum for the internal states.
    private enum state{START, IN_IDENT, HAVE_ZERO, HAVE_DOT, IN_FLOAT, IN_NUM, HAVE_EQ, HAVE_MINUS}
    state currectState = state.START;

    // 2. Loop over characters
    List<Token> scanTokens() {
        while (!isAtEnd()) {
            // Read a char
            start = pos;
            char ch = chars.charAt(pos); // get current char

            // Handle it according to the current state
            switch (currectState) {
				case state.START -> {
                    start = pos;  //save position of first char in token
                    switch (ch) {
                        case " ", "\t", "\r", "\t" -> {pos++;}
                        case "\n" -> {
                            line++;
                            pos = 0;
                        }
                        case "+" -> { //handle all single char tokens like this
                            IToken.SourceLocation srcLocation = new IToken.SourceLocation(line, pos);  // find column not pos
                            Token currentToken = new Token(IToken.Kind.PLUS, chars, srcLocation, line);
                            pos++;}
                        case "=" -> {
                            currectState = state.HAVE_EQ;
                        }
                        case "-" -> {
                            IToken currentToken = new Token(IToken.Kind.MINUS, ch, line);
                            pos++;}
                        case "*" -> {
                            IToken currentToken = new Token(IToken.Kind.TIMES, ch, line);
                            pos++;}
                        case "*" -> {
                            IToken currentToken = new Token(IToken.Kind.TIMES, ch, line);
                            pos++;}
                        case "/" -> {
                            IToken currentToken = new Token(IToken.Kind.DIV, ch, line);
                            pos++;}
                        case "%" -> {
                            IToken currentToken = new Token(IToken.Kind.MOD, ch, line);
                            pos++;}
                        case Character.isDigit(ch) -> {
                            currectState = state.IN_NUM;
                        }
                        default -> {
                            throw new IllegalStateException("lexer bug");
                        }
                    }
				}
				case state.IN_IDENT -> {

				}
				case state.HAVE_ZERO -> {
				}
				case state.HAVE_DOT -> {
				}
				case state.IN_FLOAT -> {
				}
				case state.IN_NUM -> {

				}
				case state.HAVE_EQ -> {
                    switch(ch) {
                        case ‘=‘ {
                            create token:  kind = Kind.EQUALS, position = startPos, length 2;
                            pos++;
                            default -> {
                                handle error
				}
				case state.HAVE_MINUS -> {
				}

                default -> {
                    throw new IllegalStateException("lexer bug");
                }
            } //Switch statement end
        } //While loop ends

        // When a token is recognized,  create a Token and reset the state to START.
        // When in start state, save position of first char of token�this is token pos.
        tokens.add(new Token(IToken.Kind.EOF, "", null, line));
        return tokens;
    }

    private boolean isAtEnd() {
        return pos >= chars.length();
    }

    private void addToken(IToken.Kind kind) {
        addToken(kind, null);
    }

    private void addToken(IToken.Kind kind, Object literal) {
        String text = chars.substring(start, pos);
        tokens.add(new Token(kind, text, literal, line));
    }
}
